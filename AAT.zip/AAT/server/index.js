const express=require("express")
const mongoose=require('mongoose')
const cors=require("cors")
const EmployeeModel = require('./models/Employee')

const app= express()
app.use(express.json())
app.use(cors())

mongoose.connect("mongodb://127.0.0.1:27017/CryptoAat");


const userSchema = new mongoose.Schema({
    username: String,
    password: String
});

const User = mongoose.model('User', userSchema);

// Helper functions for encryption
function stringToBits(str) {
    let bits = [];
    for (let i = 0; i < str.length; i++) {
        let bin = str.charCodeAt(i).toString(2).padStart(8, '0');
        bits = bits.concat(bin.split('').map(Number));
    }
    return bits;
}

function bitsToString(bits) {
    let str = '';
    for (let i = 0; i < bits.length; i += 8) {
        let byte = bits.slice(i, i + 8).join('');
        str += String.fromCharCode(parseInt(byte, 2));
    }
    return str;
}

function desEncryptBlock(block, key) {
    let encryptedBlock = [];
    for (let i = 0; i < block.length; i++) {
        encryptedBlock.push(block[i] ^ key[i % key.length]);
    }
    return encryptedBlock;
}

function desDecryptBlock(block, key) {
    let decryptedBlock = [];
    for (let i = 0; i < block.length; i++) {
        decryptedBlock.push(block[i] ^ key[i % key.length]);
    }
    return decryptedBlock;
}

function doubleDesEncrypt(plainText, key1, key2) {
    let plainBits = stringToBits(plainText);
    let encryptedBits1 = desEncryptBlock(plainBits, stringToBits(key1));
    let encryptedBits2 = desEncryptBlock(encryptedBits1, stringToBits(key2));
    return bitsToString(encryptedBits2);
}

function doubleDesDecrypt(encryptedText, key1, key2) {
    let encryptedBits = stringToBits(encryptedText);
    let decryptedBits1 = desDecryptBlock(encryptedBits, stringToBits(key2));
    let decryptedBits2 = desDecryptBlock(decryptedBits1, stringToBits(key1));
    return bitsToString(decryptedBits2);
}

/* app.post("/login",(req,res) => {
    const {email,password} = req.body;
    EmployeeModel.findOne({email:email})
    .then(user =>{
        if(user){
            if(user.password === password){
                res.json("Success")
            }
            else{
                res.json("The password is incorrect")
            }
        }else{
            res.json("No record existed")
        }
    })
}) */


app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    const encryptedPassword = doubleDesEncrypt(password, '12345678', 'abcdefgh');
    const encryptedEmail = doubleDesEncrypt(email, '12345678', 'abcdefgh');
    const user = await EmployeeModel.findOne({ email: encryptedEmail, password: encryptedPassword })
    .then(user =>{
        if(user){
            if(user.password === encryptedPassword){
                res.json("Success")
            }
            else{
                res.json("The password is incorrect")
            }
        }else{
            res.json("No record existed")
        }
    })
});

/* app.post('/register',(req,res)=>{
    EmployeeModel.create(req.body)
    .then(employees => res.json(employees))
    .catch(err => res.json(err))
}) */

app.post('/register', async (req, res) => {
    const { email, password } = req.body;
    const encryptedPassword = doubleDesEncrypt(password, '12345678', 'abcdefgh');
    const encryptedEmail = doubleDesEncrypt(email, '12345678', 'abcdefgh');
    const newUser = new EmployeeModel({ email: encryptedEmail, password: encryptedPassword });
    await newUser.save();
    res.send('User registered successfully');
});

app.listen(3001,() =>{
    console.log("Server is running")
})