import React from 'react'

function Home(){
    return(
        <h2>Home Page</h2>
    )
}
export default Home;